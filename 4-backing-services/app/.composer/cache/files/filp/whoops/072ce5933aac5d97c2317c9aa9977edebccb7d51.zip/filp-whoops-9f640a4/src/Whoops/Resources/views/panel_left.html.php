<?php $tpl->render($header_outer) ?>
<?php $tpl->render($frames_description) ?>
<?php $tpl->render($frames_container) ?>